#ifndef _AUDIOSORT_H_
#define _AUDIOSORT_H__

#include "objects.h"

extern void audioSortDir(char *);
extern void audioSort(struct audio *, char *, char *);

#endif

