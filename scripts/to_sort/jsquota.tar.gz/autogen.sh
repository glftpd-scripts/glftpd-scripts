#!/bin/sh -ex

autoconf
