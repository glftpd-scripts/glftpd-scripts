#!/bin/sh

# This script can be used as a QCOMPLETE script to
# update the information on MSS slave sites.

# The glftpd root path
GLFTPD=/glftpd
# MSS hub config file
HUBCONF=/glftpd/bin/mss-hub.conf

##########

. $HUBCONF || exit 1

for slave in $SLAVES
do
	echo "SYNC BASIC *" >> $GLFTPD/etc/$slave.actions
	chmod 666 $GLFTPD/etc/$slave.actions
done

