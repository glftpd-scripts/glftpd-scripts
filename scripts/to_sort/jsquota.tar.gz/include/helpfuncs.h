#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>

#include "objects.h"

#define MAXSTRLEN 4096

char *getcfgvalue(FILE *, const char *, char *);
long getcfgvalue_l(FILE *, const char *);
void writelog(const char *, const char *, ...);

// count lines in a file
size_t countlines(const char *);

int daysleft(time_t, time_t, int);

char *find_last_of(char *, const char *);
char *find_first_of(char *, const char *);

//void strip_whitespaces(char *);

void runcomplete(const struct settings *, char *, ...);

#endif
