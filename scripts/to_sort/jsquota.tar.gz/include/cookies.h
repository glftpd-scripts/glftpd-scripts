#ifndef COOKIES_H
#define COOKIES_H

/*
	%U - current user
	%G - group for %U
	%N - the user ahead of the current one
	%P - the user behind the current one

	%D - days left of quota or trial for %U

	%p - stat position 

	%Mn - MB uploaded (for the nth stat section).
	      not specifying n shows a total.

	%Ln - quota limit (for the nth quota limit)
	      for instance, leaving out the number n
		  shows quota limit 1 (referred to as 0),
		  while %L2 shows the quota limit for
		  quota limit 3.

	%l - trial limit

	%Q - MB uploaded minus quota limit
	%T - MB uploaded minus trial limit

	%q - quota limit minus MB uploaded
	%t - trial limit minus MB uploaded

	%d - _TOTAL_ MB difference between %U and %P

	%n - arbitrary number passed as the last argument to cookieconvert

	%b - bold
	%u - underlined
	%c - colored
*/

/* the user is number one */
#define NUMBERONE "%b%c3%U%c%b is %b#%p%b with %b%M%b/%LMB uploaded. Try to beat it if you can!"

/* output for quota with toplimit */
#define TOPPASS "%b%c3%U%c%b is %b#%p%b with %b%M%b/%LMB uploaded. Needs to upload %b%d%bMB to beat %b%N%b."
#define TOPFAIL "%b%c4%U%c%b is %b#%p%b with %b%M%b/%LMB uploaded. Needs to upload %b%d%bMB to beat %b%N%b."

/* ordinary quota output */
#define QPASS "%b%c3%U%c%b is %b#%p%b with %b%M%b/%LMB uploaded. Needs to upload %b%d%bMB to beat %b%N%b."
#define QFAIL "%b%c4%U%c%b at %b#%p%b has uploaded %b%M%b/%LMB and has %b%D%b days to go."

/* output for users on trial */
#define TPASS "%b%c3%U%c%b has passed the trial of %b%l%bMB with %b%T%bMB."
#define TFAIL "%b%c4%U%c%b still misses %b%t%bMB of the %b%l%bMB trial limit and has %b%D%b days to go."
#define TGONE "%b%c4%U%c%b has failed the trial of %b%l%bMB with %b%M%bMB  and will be deleted."

/* for checking all users on quota */
#define QCHECKLINEP "%b%U%b %MMB - "
#define QCHECKLINEF QCHECKLINEP
#define QCHECKFOOT "Total: %n"

/* as above but for trial */
#define TCHECKLINEP "%b%c3%U%c%b %MMB - "
#define TCHECKLINEF "%b%c4%U%c%b %MMB - "
#define TCHECKFOOT QCHECKFOOT

/* self-explanatory */
#define DELETED "%b%U%b/%G is deleted."
#define EXEMPT "%b%U%b/%G is exempt from the quota, but has uploaded %b%M%b/%LMB anyway."
#define NOTRIALS "Nobody is on trial at the moment."
#define TOOLONG "A username cannot exceed 24 characters."

#endif

