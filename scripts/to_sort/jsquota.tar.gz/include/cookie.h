#ifndef COOKIE_H
#define COOKIE_H

#include "objects.h"

void cookieconvert(struct settings *, struct gluser *, unsigned int, char *, char *, size_t, int);

#endif

