#ifndef STATIC_H
#define STATIC_H

#ifndef _LIMITS_H_
  #define _LIMITS_H_
  #ifdef __BSD_
    #include <sys/syslimits.h>
  #else
    #include <limits.h>
    #include <syslimits.h>
  #endif
#endif

#define MAXEXEMPTGROUPS 100
#define MAXEXEMPTUSERS 20
#define MAXFILESIZE 2048
#define MAXSTATSECTIONS 10

static const int MONTHS[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
static const int MONTHS_LEAP[] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

#endif

