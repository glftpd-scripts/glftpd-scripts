#ifndef OBJECTS_H
#define OBJECTS_H

#include <gluserfile.h>
#include "static.h"

struct gluser {
	
	char group[24];
	char uname[24];
	
	ASECTION section[2];

	off_t mb;
	
	short int trial;
	short int exempt;
	short int deleted;

	/* month, day, year the user was added */
	int m;
	int d;
	int y;

};

struct _gq {

	char gname[24];
	int limit;
	
};

struct groupquota {

	struct _gq *gq;
	size_t n;

};

struct settings {

	char glroot[PATH_MAX];
	char userdir[PATH_MAX];
	char passwd[PATH_MAX];
	char trialfile[PATH_MAX];
	char logfile[PATH_MAX];
	
	char qcomplete[PATH_MAX];
	char tcomplete[PATH_MAX];
	
	char egroups[MAXEXEMPTGROUPS][24];
	char eusers[MAXEXEMPTUSERS][24];

	short graceperiod;
	short excludeleech;
	short failtotrial;
	
	char excludeflags[22];
	
	int *qlimit;
	int tlimit;
	int toplimit;

	struct groupquota gquota;

	int trialdays;
	
	/* number of quota sections */
	int quotas;

	/* number of users in th passwd file */
	/* might not belong as a setting.. but who cares for now */
	int n_users;

};

struct trialuser {
	
	char uname[24];
	time_t date;

};

#endif

