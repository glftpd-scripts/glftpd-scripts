#ifndef TRIALFUNCS_H
#define TRIALFUNCS_H

#include "objects.h"

int addtotrial(const struct settings *, const char *);
int removefromtrial(const struct settings *, const char *);
int trialuser(const struct settings *, const char *);
void printtrials(const struct settings *);

#endif

