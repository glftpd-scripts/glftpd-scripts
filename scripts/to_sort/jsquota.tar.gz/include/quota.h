#ifndef QUOTA_H
#define QUOTA_H

void print_usage();
void full_help();

#endif

