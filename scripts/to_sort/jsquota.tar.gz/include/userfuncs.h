#ifndef USERFUNCS_H
#define USERFUNCS_H

void quotacheck(struct gluser *, struct settings *, int);
void trialcheck(struct gluser *, struct settings *);
void singlecheck(struct gluser *, struct settings *, const char *);

void quotacleanup(struct gluser *, struct settings *, int);
void trialcleanup(struct gluser *, struct settings *, int);

// return the date a user was added, if on trial, otherwise 0
int trialuser(const struct settings *, const char *);

// adds flag 6 to a user file.
// returs 0 if it went ok, 1 if a FLAGS line doesn't exit
// and 2 if something went wrong
int addflagsix(const struct settings *, const char *);

int userexists(const char *, const char *);

short passed(struct settings *, struct gluser *, int);

#endif

