#ifndef GLFUNCTIONS_H
#define GLFUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include <gluserfile.h>
#include "quota.h"

#define total_mb(x) total_kb(x)/1024

struct settings *readconfig(const char *, struct settings *);

struct gluser *builduserlist(struct settings *, struct gluser *);
struct gluser *getusers(struct settings *, struct gluser *);
int ufile_exists(struct settings *, char *);
void sortusers(struct gluser *, const int);

off_t total_kb(ASECTION *);
off_t *parse_statline(struct gluser *, off_t *, char *);
off_t total_stat(off_t *, int);

void buildqlimit(struct settings *, char *);
void buildgqlimit(struct settings *, char *);

#endif

