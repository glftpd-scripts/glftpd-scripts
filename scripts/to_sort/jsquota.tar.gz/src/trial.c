#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "quota.h"
#include "glfuncs.h"
#include "userfuncs.h"
#include "trialfuncs.h"
#include "helpfuncs.h"

/*
	to use this program you need to have the config somewhere in
	the glftpd root path 

	the way this program runs from gl is quite ugly. it needs to
	look something like this:

		site_cmd ADDTRIAL EXEC /bin/trial -g[:space:]-m1[:space:]-r/etc/quota.conf[:space:]-u
		site_cmd DELTRIAL EXEC /bin/trial -g[:space:]-m2[:space:]-r/etc/quota.conf[:space:]-u
		site_cmd PRINTTRIALS EXEC /bin/trial -g[:space:]-m3[:space:]-r/etc/quota.conf

		custom-addtrial 1
		custom-deltrial 1
		custom-printtrials 1

*/

int main(int argc, char **argv)
{
	short gl = 0;
	int ch, date;
	char uname[24] = { 0 }, conf[PATH_MAX] = { 0 }, temp[PATH_MAX], mode = 0;
	struct settings s;
	
	while ((ch = getopt(argc, argv, "gm:r:u:")) != -1) {
		switch (ch) {
			case 'g':
				gl = 1;
				break;
			case 'm':
				mode = *optarg;
				break;
			case 'r':
				strncpy(conf, optarg, PATH_MAX);
				break;
			case 'u':
				strncpy(uname, optarg, 24);
				break;
		}
	}

	/* no config or username specified */
	if (strlen(conf) == 0 || (strlen(uname) == 0 && mode != '3'))
		return EXIT_FAILURE;
	
	readconfig(conf, &s);
	
	if (gl == 0) {
		snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.userdir);
		strncpy(s.userdir, temp, PATH_MAX);
		snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.passwd);
		strncpy(s.passwd, temp, PATH_MAX);
		snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.trialfile);
		strncpy(s.trialfile, temp, PATH_MAX);
	}

	switch (mode) {
		case '1':
			if (addtotrial(&s, uname) > 0)
				printf("Successfully added user %s to trial.\n", uname);
			break;
		case '2':
			date = removefromtrial(&s, uname);

			if (date > 0)
				printf("Successfully removed user %s (who had %i days left) from trial.\n",
				       uname, daysleft(time(NULL), date, s.trialdays));
			else if (date == 0)
				printf("User %s isn't on trial.\n", uname);

			break;
		case '3':
			printtrials(&s);
			break;
		default:
			return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

