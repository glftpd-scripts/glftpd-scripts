#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>
#include <stdarg.h>

#include "helpfuncs.h"
#include "glfuncs.h"
#include "userfuncs.h"
#include "trialfuncs.h"
#include "objects.h"
#include "cookie.h"
#include "cookies.h"

void quotacheck(struct gluser *userlist, struct settings *s, int mode)
{
	int i, passed_u=0, failed_u=0;
	char output[1024];

	sortusers(userlist, s->n_users);
	
	for (i=0; i < s->n_users; i++) {

		if (!userlist[i].exempt && !userlist[i].deleted) {
	
			if (mode == 0) {
				switch (passed(s, &userlist[i], i)) {
					case 1:
					case 3:
						cookieconvert(s, userlist, i, QCHECKLINEP, output, sizeof(output), 0);
						printf("%s", output);
						passed_u++;
						break;
				}
			} else if (mode == 1) {
				switch (passed(s, &userlist[i], i)) {
					case -2:
					case -1:
						cookieconvert(s, userlist, i, QCHECKLINEF, output, sizeof(output), 0);
						printf("%s", output);
						failed_u++;
						break;
				}
			}
		}
	}

	if (mode == 0)
		cookieconvert(0, 0, 0, QCHECKFOOT, output, sizeof(output), passed_u);
	else if (mode == 1)
		cookieconvert(0, 0, 0, QCHECKFOOT, output, sizeof(output), failed_u);

	printf("%s\n", output);
}

void trialcheck(struct gluser *userlist, struct settings *s)
{
	int i, trials=0;
	char output[1024];
	
	sortusers(userlist, s->n_users);
	
	for (i=0; i < s->n_users; i++) {
		switch (passed(s, &userlist[i], i)) {
			case 2:
				cookieconvert(s, userlist, i, TCHECKLINEP, output, sizeof(output), 0);
				printf("%s", output);
				removefromtrial(s, userlist[i].uname);
				trials++;
				break;
			case -3:
			case 0:
				cookieconvert(s, userlist, i, TCHECKLINEF, output, sizeof(output), 0);
				printf("%s", output);
				trials++;
				break;
		}
	}

	if (trials == 0)
		cookieconvert(0, 0, 0, NOTRIALS, output, sizeof(output), 0);
	else
		cookieconvert(0, 0, 0, TCHECKFOOT, output, sizeof(output), trials);
	
	printf("%s\n", output);
}

void singlecheck(struct gluser *userlist, struct settings *s, const char *user)
{
	int i;
	char *p=0, output[2048];
	short exists=0;
	struct timeval unixtime;
	struct tm *timetm;
    
	if (strlen(user) > 24) {
		cookieconvert(0, 0, 0, TOOLONG, output, sizeof(output), 0);
		printf("%s\n", output);
		exit(EXIT_FAILURE);
	}

	gettimeofday(&unixtime, NULL);
	timetm = localtime((time_t *)&unixtime.tv_sec);

	sortusers(userlist, s->n_users);

	for (i=0; i < s->n_users; i++) {
		if (strncmp(user, userlist[i].uname, 24) == 0) {
			exists = 1;

			if (userlist[i].deleted == 1) {
				p = DELETED;
				goto PRINT;
			} else if (userlist[i].exempt == 1) {
				p = EXEMPT;
				goto PRINT;
			}
				
			switch (passed(s, &userlist[i], i)) {
				case -2:
					p = TOPFAIL;
					break;
				case 3:
					(i == 0 ? (p = NUMBERONE) : (p = TOPPASS));
					break;
				case 1:
					(i == 0 ? (p = NUMBERONE) : (p = QPASS));
					break;
				case -1:
					p = QFAIL;
					break;
				case -3:
					p = TGONE;
					addflagsix(s, userlist[i].uname);
					removefromtrial(s, userlist[i].uname);
					break;
				case 0:
					p = TFAIL;
					break;
				case 2:
					p = TPASS;
					removefromtrial(s, userlist[i].uname);
					break;
			}				
				
PRINT:
			cookieconvert(s, userlist, i, p, output, sizeof(output), 0);
			printf("%s\n", output);
		}
	}
	if (exists == 0)
		printf("No such user \"%s\".\n", user);
}

void quotacleanup(struct gluser *userlist, struct settings *s, int mode)
{
	int i, users=0;
	char *deld=0;
	struct timeval unixtime;
	struct tm *time;

	if ((s->quotas != -1 && s->quotas < 1) || s->n_users < 1)
		return;
    
	gettimeofday(&unixtime, NULL);
	time = localtime((time_t *)&unixtime.tv_sec);

	/* only do serious stuff at the end of the month */
	if (time->tm_year%4 == 0) {
		if (time->tm_mday != MONTHS_LEAP[time->tm_mon] && mode == 0)
			return;
	} else {
		if (time->tm_mday != MONTHS[time->tm_mon] && mode == 0)
			return;
	}
	
	sortusers(userlist, s->n_users);

	for (i=0; i < s->n_users; i++) {

		if (!userlist[i].exempt && !userlist[i].deleted) {
			switch (passed(s, &userlist[i], i)) {
				case -2:
				case -1:
					
					if (mode == 1) {
						printf("%s at #%i only has %lldMB and would have been deleted.\n",
							   userlist[i].uname, i+1, userlist[i].mb);
					} else {
						if (s->failtotrial) {
						
							if (addtotrial(s, userlist[i].uname) == -1)
								continue;
								
							writelog(s->logfile, "quotacleanup: %s / %ldMB / #%i added to trial.\n",
									 userlist[i].uname, userlist[i].mb, i+1);
									 
						} else if (addflagsix(s, userlist[i].uname) == 0) {
						
							writelog(s->logfile, "quotacleanup: %s / %ldMB / #%i deleted.\n",
							         userlist[i].uname, userlist[i].mb, i+1);

						}				
						users++;
						deld = realloc(deld, 24*users);
					}
					
					break;
				case 1:
				case 3:
					if (mode == 1) {
						printf("%s at #%i with %lldMB passed the quota.\n",
						       userlist[i].uname, i+1, userlist[i].mb);
					}
					break;
			}
		}

	}
	
	if (mode == 1)
		printf("Cleanup complete, %i users deleted.\n", users);
	else {
		writelog(s->logfile, "quotacleanup: Cleanup complete, %i users deleted.\n", users);
		if (s->qcomplete[0] != '\0')
			runcomplete(s, "%s%s%s%i", "/bin/sh", s->qcomplete, deld, users);
		if (deld) free(deld);
	}

}

void trialcleanup(struct gluser *userlist, struct settings *s, int mode)
{
	int i, f_users=0, p_users=0;
	char *failed_users=0, *passed_users=0;

	if (s->tlimit < 1 || s->n_users < 1)
		return;
	else if (strlen(s->trialfile) == 0) {
		writelog(s->logfile, "TRIALFILE not set, can't continue.\n");
		return;
	}

	sortusers(userlist, s->n_users);
	
	for (i=0; i < s->n_users; i++) {
		
		switch (passed(s, &userlist[i], i)) {
			case -3:
				addflagsix(s, userlist[i].uname);
				writelog(s->logfile, "trialcleanup: %s / %ldMB deleted.\n",
						 userlist[i].uname, userlist[i].mb);
				removefromtrial(s, userlist[i].uname);
				writelog(s->logfile, "trialcleanup: %s / %ldMB removed from trial.\n",
				         userlist[i].uname, userlist[i].mb);
				f_users++;
				failed_users = realloc(failed_users, 24*f_users);
				break;
			case 2:
				removefromtrial(s, userlist[i].uname);
				writelog(s->logfile, "trialcleanup: %s / %ldMB removed from trial.\n",
				         userlist[i].uname, userlist[i].mb);
				p_users++;
				passed_users = realloc(passed_users, 24*p_users);
				break;
		}

	}

	if (mode == 1)
		printf("Cleanup complete, %i passed, %i deleted.\n", p_users, f_users);
	else {
		writelog(s->logfile, "trialcleanup: Cleanup complete, %i passed, %i deleted.\n", p_users, f_users);
		if (s->tcomplete[0] != '\0')
			runcomplete(s, "%s%s%s%i%s%i", "/bin/sh", s->tcomplete, passed_users, p_users, failed_users, f_users);
		if (failed_users) free(failed_users);
		if (passed_users) free(passed_users);
	}
}

int addflagsix(const struct settings *s, const char *user)
{
	
	char buf[MAXFILESIZE], *p, userpath[256], tmp;
	FILE *userfile;
	struct stat sb;
	
	memset(&userpath, 0, sizeof(userpath));
	snprintf(userpath, sizeof(userpath), "%s/%s", s->userdir, user);

	if (stat(userpath, &sb) == -1) {
		writelog(s->logfile, "addflagsix: %s\n", strerror(errno));
		return 2;
	}
	
	if (sb.st_size > MAXFILESIZE) {
		writelog(s->logfile, "addflagsix: %s exceeds %i bytes." \
		         " Increase MAXFILESIZE if this is correct.\n",
			 userpath, MAXFILESIZE);
		return 2;
	}
	
	userfile = fopen(userpath, "r");
	if (userfile == NULL) {
		writelog(s->logfile, "addflagsix: Couldn't open %s for" \
		         " reading: %s\n", userpath, strerror(errno));
		return 2;
	}
		
	memset(&buf, 0, sizeof(buf));
	fread(&buf, sb.st_size, 1, userfile);

	p = strstr(buf, "\nFLAGS ");
	if (p != NULL) {
		freopen(userpath, "w+", userfile);

		// "\nFLAGS " consists of 7 characters
		p += 7;
		
		tmp = *p; *p = '\0';
		
		fputs(buf, userfile);
		
		*p = tmp;

		while (*p != '\n' && *p < '6') {
			fputc(*p, userfile);
			p++;
		}

		fputc('6', userfile);
		fputs(p, userfile);
		
		fclose(userfile);
		return 0;
	} else {
		fclose(userfile);
		return 1;
	}

}

/* check if uname exists in passwdfile */
int userexists(const char *passwdfile, const char *uname)
{
	FILE *fp;
	char *p, buf[24];

	if (!(fp = fopen(passwdfile, "r")))
		return 0;

	while (fgets(buf, sizeof(buf), fp)) {
		if ((p = strstr(buf, ":")))
			*p = '\0';
		if (strncmp(buf, uname, 24) == 0)
			return 1;
		while (fgetc(fp) != '\n');
	}
	
	return 0;
}

/*
	return values:	-4 - failed group quota
					-3 - failed trial and period is over
					-2 - failed quota with toplimit on
	                -1 - failed quota
					0  - failed trial and period going on
					1  - passed quota
					2  - passed trial
					3  - passed quota with toplimit on
					4  - passed group quota
*/
#warning: implement group quota check
short passed(struct settings *s, struct gluser *u, int pos)
{
	int i;
	off_t mb;
	time_t date;

	if (u->trial == 1) {

		/* on trial */
		date = trialuser(s, u->uname);

		if (daysleft(time(NULL), date, s->trialdays) < 0)
			return (u->mb >= s->tlimit ? 2 : -3);
		else
			return (u->mb >= s->tlimit ? 2 : 0);

	} else if (s->quotas == -1) {
	
		/* one quota section */
		if (u->mb >= s->qlimit[1]) {
			if (s->toplimit > 0)
				return (pos < s->toplimit ? 3 : -2);
			else 
				return 1;
		} else
			return (s->toplimit > 0 ? -2 : -1);

	} else {

		/* multiple quota sections */
		for (i = 0; i < s->quotas*2; i += 2) {
			
			if (u->section[0].n < (s->qlimit[i]+1))
				continue;
			else {
				mb = (u->section[0].s[s->qlimit[i]].kilobytes)/1024;
			
				if (mb >= s->qlimit[i+1]) {
					if (s->toplimit > 0)
						return (pos < s->toplimit ? 3 : -2);
					else 
						return 1;
				}
			}

		}
		
		/* none of the quotas are passed */
		return (s->toplimit > 0 ? -2 : -1);

	}
}

