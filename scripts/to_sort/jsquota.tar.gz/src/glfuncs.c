#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>

#include "glfuncs.h"
#include "helpfuncs.h"
#include "userfuncs.h"
#include "objects.h"
#include "static.h"

/* this shit turned ugly, better make some kind of loop */
struct settings *readconfig(const char *filename, struct settings *s)
{
	int i;
	char *buf=0, *tempbuf, *p;
	FILE *config;
	
	if ((config = fopen(filename, "r")) == NULL) {
		perror(filename);
		exit(EXIT_FAILURE);
	}
	
	if (!s)
		s = malloc(sizeof(struct settings));

	s->qlimit = 0;

	// we must read these exempt values delimited
	// by space
	if ((buf = getcfgvalue(config, "EXEMPTGROUPS", buf))) {
		bzero(s->egroups, sizeof(s->egroups));
		if ((p = strtok(buf, " \t"))) {
			strncpy(s->egroups[0], p, 24);
			for (i=0; i < MAXEXEMPTGROUPS; i++) {
				if ((p = strtok(NULL, " \t")))
					strncpy(s->egroups[i], p, 24);
				else
					break;
			}
		} 
	}
	
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "EXEMPTUSERS", buf))) {
		bzero(s->eusers, sizeof(s->eusers));
		if ((p = strtok(buf, " \t"))) {
			strncpy(s->eusers[0], p, 24);
			for (i=0; i < MAXEXEMPTUSERS; i++) {
				if ((p = strtok(NULL, " \t")))
					strncpy(s->eusers[i], p, 24);
				else
					break;
			}
		} 
	} else
		buf = tempbuf;

	// GLROOT, USERDIR and PASSWD are vital
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "GLROOT", buf)))
		strcpy(s->glroot, buf);
	else {
		free(tempbuf);
		free(s);
		fprintf(stderr, "ERROR: Couldn't read 'GLROOT' from" \
				" the config file.\n");
		exit(EXIT_FAILURE);
	}
	
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "USERDIR", buf)))
		strcpy(s->userdir, buf);
	else {
		free(tempbuf);
		free(s);
		fprintf(stderr, "ERROR: Couldn't read 'USERDIR' from" \
				" the config file.\n");
		exit(EXIT_FAILURE);
	}
	
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "PASSWD", buf)))
		strcpy(s->passwd, buf);
	else {
		free(tempbuf);
		free(s);
		fprintf(stderr, "ERROR: Couldn't read 'PASSWD' from" \
				" the config file.\n");
		exit(EXIT_FAILURE);
	}
	
	s->qcomplete[0] = s->tcomplete[0] = s->trialfile[0]
	                = s->logfile[0] = '\0';

	memset(s->excludeflags, 0, sizeof(s->excludeflags));

	s->excludeleech = 0;
	
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "QCOMPLETE", buf)))
		strncpy(s->qcomplete, buf, sizeof(s->qcomplete));
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "TCOMPLETE", buf)))
		strncpy(s->tcomplete, buf, sizeof(s->tcomplete));
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "TRIALFILE", buf)))
		strncpy(s->trialfile, buf, sizeof(s->trialfile));
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "LOGFILE", buf)))
		strncpy(s->logfile, buf, sizeof(s->logfile));
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "EXCLUDEFLAGS", buf)))
		strncpy(s->excludeflags, buf, sizeof(s->excludeflags));
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "EXCLUDELEECH", buf)))
		s->excludeleech = 1;
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "FAILTOTRIAL", buf)))
		s->failtotrial = 1;
	else
		buf = tempbuf;

	tempbuf = buf;
	if ((buf = getcfgvalue(config, "QUOTALIMIT", buf)))
		buildqlimit(s, buf);
	else
		buf = tempbuf;

	s->gquota.gq = 0;
	tempbuf = buf;
	if ((buf = getcfgvalue(config, "GROUPQUOTA", buf)))
		buildgqlimit(s, buf);
	else
		buf = tempbuf;

	free(buf);

	s->tlimit = getcfgvalue_l(config, "TRIALLIMIT");
	s->toplimit = getcfgvalue_l(config, "TOPLIMIT");
	s->trialdays = getcfgvalue_l(config, "TRIALDAYS");
	s->graceperiod = getcfgvalue_l(config, "GRACEPERIOD");

	fclose(config);

	return s;
}

struct gluser *builduserlist(struct settings *s, struct gluser *userlist)
{
	int y=0;
	unsigned int u=0, i;
	char userpath[PATH_MAX], temp[256], tmpgrp[24], primgroup[24];
	char *p1, *p2;
	struct stat sb;
	struct timeval unixtime;
	struct tm *time;
	FILE *userfile;
	
	userlist = getusers(s, userlist);

	if (s->n_users == 0) {
		writelog(s->logfile, "builduserlist: No users found.\n");
		exit(EXIT_FAILURE);
	} else {
		
		// do stuff with users
		for (y=0; y < s->n_users; y++) {

			userlist[y].exempt = 0;
			userlist[y].deleted = 0;
			userlist[y].trial = 0;
			userlist[y].section[0].s =
				userlist[y].section[1].s = 0;
			
			gettimeofday(&unixtime, NULL);
			time = localtime((time_t *)&unixtime.tv_sec);
			
			if (((userlist[y].y+2000) == (time->tm_year+1900)) &&
			    (userlist[y].m == time->tm_mon+1) &&
			    (userlist[y].d > s->graceperiod) &&
			    (trialuser(s, userlist[y].uname) == 0))
				userlist[y].exempt = 1;
			
			userpath[0] = primgroup[0] = temp[0] = '\0';

			// default group
			strcpy(primgroup, "NoGroup");
			
			snprintf(userpath, sizeof(userpath), "%s/%s",
			         s->userdir, userlist[y].uname);
			
			if (stat(userpath, &sb) == -1) {
				writelog(s->logfile, "builduserlist: Couldn't stat %s: %s\n",
				         userpath, strerror(errno));
				continue;
			}
			
			if (sb.st_size > MAXFILESIZE) {
				writelog(s->logfile, "builduserlist: %s is larger than %i bytes, skipping.\n",
					 userpath, MAXFILESIZE);
				continue;
			}
			
			// exempt users
			for (u=0; u < MAXEXEMPTUSERS; u++)
				if (strncmp(userlist[y].uname, s->eusers[u], 24) == 0)
					userlist[y].exempt = 1;
			
			if (!(userfile = fopen(userpath, "r"))) {
				writelog(s->logfile, "builduserlist: Couldn't open %s for reading: %s\n",
				         userpath, strerror(errno));
				continue;
			}				
			
			while (fgets(temp, sizeof(temp), userfile)) {
				
				if (strncmp(temp, "MONTHUP", 7) == 0)
					ufile_section(&userlist[y].section[0], temp+8);
				else if(strncmp(temp, "ALLUP", 5) == 0)
					ufile_section(&userlist[y].section[1], temp+6);
				else if (strncmp(temp, "GROUP", 5) == 0) {

					p1 = strstr(temp, " ");
					strip_whitespaces(p1);
					while (*p1 == ' ' || *p1 == '\t')
						p1++;

					if ((p2 = strstr(p1, " ")))
						*p2 = '\0';
	
					memset(&tmpgrp, 0, 24);
					strncpy(tmpgrp, p1, 24);
					
					if (strcmp(primgroup, "NoGroup") == 0)
						strncpy(primgroup, tmpgrp, 24);
					
					for (u=0; u < MAXEXEMPTGROUPS; u++) {
						if (strncmp(tmpgrp, s->egroups[u], 24) == 0) {
							userlist[y].exempt = 1;
							break;
						}
					}

				} else if (s->excludeleech == 1 && (strncmp(temp, "RATIO 0", 7) == 0)) {
					userlist[y].exempt = 1;
				} else if (strncmp(temp, "FLAGS", 5) == 0) {
					for (u=6; u < strlen(temp); u++) {
						for (i=0; i < sizeof(s->excludeflags); i++)
							if (temp[u] == s->excludeflags[i])
								userlist[y].exempt = 1;

						if (temp[u] == '6')
							userlist[y].deleted = 1;
					}
				}

			}
			fclose(userfile);
			
			if (userlist[y].exempt == 0)
				if (trialuser(s, userlist[y].uname) > 0)
					userlist[y].trial = 1;
	
			strncpy(userlist[y].group, primgroup, 24);
			if (userlist[y].trial == 0)
				userlist[y].mb = total_mb(&userlist[y].section[0]);
			else
				userlist[y].mb = total_mb(&userlist[y].section[1]);
		}
	}
	return userlist;
}

struct gluser *getusers(struct settings *s, struct gluser *users)
{
	int i, u;
	char fbuf[256], *p1, *p2, *p3;
	FILE *passwdfile;
	
	users = realloc(users, sizeof(struct gluser)*s->n_users);

	if (!(passwdfile = fopen(s->passwd, "r"))) {
		perror(s->passwd);
		return users;
	}
	
	u = 0;
	while ((fgets(fbuf, sizeof(fbuf), passwdfile))) {
	
		p1 = fbuf;
		p2 = strsep(&p1, ":");
		
		if (ufile_exists(s, p2) == -1)
			continue;
		
		strncpy(users[u].uname, p2, 24);

		// date handling
		for (i=0; i < 4; i++)
			p2 = strsep(&p1, ":");

		p3 = strsep(&p1, ":");
		*p3 = '\0';
		
		// some entries can simply be 0, and we can't take
		// that.. but this is not really safe anyway
		if (strlen(p2) > 1) {
			users[u].m = strtol(strsep(&p2, "-"), NULL, 10);
			users[u].d = strtol(strsep(&p2, "-"), NULL, 10);
			users[u].y = strtol(strsep(&p2, "-"), NULL, 10);
		} else {
			users[u].m = users[u].d = users[u].y = 0;
		}
		
		u++;
	}

	fclose(passwdfile);
	
	users = realloc(users, sizeof(struct gluser)*u);
	s->n_users = u;
	
	return users;
}

int ufile_exists(struct settings *s, char *uname)
{
	static char path[PATH_MAX];
	static struct stat sb;

	snprintf(path, PATH_MAX, "%s/%s", s->userdir, uname);

	return stat(path, &sb);
}

void sortusers(struct gluser *users, const int n_users)
{
	int i, u;
	struct gluser temp;

	// sort after mb
	for (i = n_users-1; i >= 0; i--) {
		for (u = i; u >= 0; u--) {
			if (users[i].mb > users[u].mb) {
				temp = users[i];
				users[i] = users[u];
				users[u] = temp;
			}
		}
	}

	// put all exempted users at the bottom
	for (i=0; i < n_users; i++) {
		for (u = i; u < n_users; u++) {
			if (users[i].exempt > users[u].exempt) { 
				temp = users[i];
				users[i] = users[u];
				users[u] = temp;
			}
		}
	}

}

off_t total_kb(ASECTION *sect)
{
	int i;
	off_t total = 0;

	for (i = 0; i < sect->n; i++)
		total += sect->s[i].kilobytes;

	return total;
}

/*off_t *parse_statline(struct gluser *u, off_t *val, char *temp)
{
	int args=0, i, n=0;
	char *p1, *p2, **numbers=0;

	while (*temp == ' ') temp++;

	strip_whitespaces(temp);

	for (p2 = p1 = temp; *p1; p1++) {
		switch (*p1) {
			case ' ':
				*p1 = '\0';
				numbers = realloc(numbers, sizeof(char *)*(args+1));
				numbers[args] = p2;
				p2 = p1+1;
				args++;
		}
	}
	
	// get the last field too
	if (strlen(p2) > 0) {
		numbers = realloc(numbers, sizeof(char *)*(args+1));
		numbers[args] = p2;
		args++;
	}

	// the second number is kilobytes
	for (i = 1; i < args; i += 3) {
		val = realloc(val, sizeof(off_t)*(n+1));
		val[n] = (off_t)strtol(numbers[i], NULL, 10);
		n++;
	}
	if (numbers)
		free(numbers);
	
	u->sections = n;
	
	return val;
}

off_t total_stat(off_t *val, int sections)
{
	int i;
	off_t ret=0;
	
	for (i=0; i < sections; i++)
		ret += val[i];

	return ret;
}*/

/*
   quotaline = int 
   or
   quotaline = int0:int int1:int intN:int
*/
void buildqlimit(struct settings *s, char *quotaline)
{
	int n=0;
	char *p1 = quotaline, *p2;
	
	while (*p1 == ' ' || *p1 == '\t')
		p1++;
	
	strip_whitespaces(p1);
	
	p2 = strstr(p1, ":");

	s->quotas = 0;
	if (p2) {

		do {
			
			s->qlimit = realloc(s->qlimit, sizeof(int *)*((n+1)*2));
			
			*p2 = '\0'; p2++;
			s->qlimit[n] = strtol(p1, NULL, 10);
			if ((p1 = find_first_of(p2, " \t"))) {
				*p1 = '\0'; p1++;
				while (*p1 == ' ' || *p1 == '\t')
					p1++;
			}

			s->qlimit[n+1] = strtol(p2, NULL, 10);

			n += 2; s->quotas++;

		} while ((p2 = strstr(p1, ":")));
		
	} else {
		s->qlimit = malloc(sizeof(int *)*2);
		s->qlimit[0] = 0;
		s->qlimit[1] = strtol(p1, NULL, 10);
		s->quotas = -1;
	}

}

void buildgqlimit(struct settings *s, char *gqline)
{
	size_t gqs = 10;
	char *p1, *p2;
	
	s->gquota.n = 0;
	s->gquota.gq = malloc(sizeof(struct _gq)*gqs);

	if ((p1 = strtok(gqline, " \t"))) {
		do {

			if ((p2 = strchr(p1, ':'))) {
				*p2 = '\0'; p2++;
				
				if (s->gquota.n > gqs) {
					gqs *= 2;
					s->gquota.gq = realloc(s->gquota.gq, sizeof(struct _gq)*gqs);
				}
				
				strncpy(s->gquota.gq[s->gquota.n].gname, p1, 24);
				s->gquota.gq[s->gquota.n].limit = strtol(p2, NULL, 10);
				s->gquota.n++;
			}
			
		} while ((p1 = strtok(NULL, " \t")));
	}

	if (s->gquota.n == 0)
		free(s->gquota.gq);
	else
		s->gquota.gq = realloc(s->gquota.gq, sizeof(struct _gq)*(s->gquota.n));
}

