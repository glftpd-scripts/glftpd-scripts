#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "helpfuncs.h"
#include "trialfuncs.h"
#include "cookie.h"

/* convert info about 'user' at 'upos' in 'in' to 'out' at the length of 'len' */
void cookieconvert(struct settings *s, struct gluser *userlist, unsigned int pos, char *in, char *out, size_t len, int n)
{
	int i, u;
	char *p, temp[len];

	bzero(out, len);
	for (p = in; *p; p++) {
		bzero(temp, len);
		if (*p == '%') {
			/* check cookies.h for definitions */
			switch (*(++p)) {
				case 'U':
					strncat(temp, userlist[pos].uname, len-strlen(out));
					break;
				case 'G':
					strncat(temp, userlist[pos].group, len-strlen(out));
					break;
				case 'N':
					if (pos > 0)
						strncat(temp, userlist[pos-1].uname, len-strlen(out));
					break;
				case 'P':
					if (pos+1 < countlines(s->passwd))
						strncat(temp, userlist[pos+1].uname, len-strlen(out));
					break;
				case 'D':
					if (userlist[pos].trial)
						snprintf(temp, len, "%i", daysleft(time(NULL), trialuser(s, userlist[pos].uname), s->trialdays));
					else
						snprintf(temp, len, "%i", daysleft(time(NULL), 0, 0));
					break;
				case 'p':
					snprintf(temp, len, "%i", pos+1);
					break;
				case 'M':
				
					if (isdigit((*(++p)))) {
						
						i = (*p)-'0';
						if (userlist[pos].section[0].n < i)
							snprintf(temp, len, "0");
						else
							snprintf(temp, len, "%ld", (userlist[pos].section[0].s[s->qlimit[i]].kilobytes)/1024);
							//snprintf(temp, len, "%lld", (userlist[pos].mnup[i]/1024));
						
					} else { 
						/* total mb */
						snprintf(temp, len, "%lld", userlist[pos].mb);
						p--;
					}
					
					break;
				case 'L':

					if (isdigit((*(++p)))) {

						i = (*p)-'0';
						snprintf(temp, len, "0");
						
						/* check if we have a quota for the specified section */
						for (u = 0; u < s->quotas*2; u += 2)
							if (s->qlimit[u] == i)
								snprintf(temp, len, "%i", s->qlimit[u+1]);
							
					} else {
						snprintf(temp, len, "%i", s->qlimit[1]);
						p--;
					}
					
					break;
				case 'l':
					snprintf(temp, len, "%i", s->tlimit);
					break;
				case 'Q':
					snprintf(temp, len, "%lld", (userlist[pos].mb-s->qlimit[0]));
					break;
				case 'q':
					snprintf(temp, len, "%lld", (s->qlimit[0]-userlist[pos].mb));
					break;
				case 'T':
					snprintf(temp, len, "%lld", (userlist[pos].mb-s->tlimit));
					break;
				case 't':
					snprintf(temp, len, "%lld", (s->tlimit-userlist[pos].mb));
					break;
				case 'd':
					if (pos > 0)
						snprintf(temp, len, "%lld", userlist[pos-1].mb-userlist[pos].mb);
					break;
				case 'b':
					*temp = '\002';
					break;
				case 'c':
					*temp = '\003';
					break;
				case 'u':
					*temp = '\004';
					break;
				case 'n':
					snprintf(temp, len, "%i", n);
					break;
				default:
					break;
			}
		} else
			*temp = *p;

		strncat(out, temp, len-strlen(out));
	}
}

