#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <pwd.h>

#include "trialfuncs.h"
#include "glfuncs.h"
#include "helpfuncs.h"
#include "objects.h"
#include "userfuncs.h"

int addtotrial(const struct settings *s, const char *uname)
{
	int fd, date;
	struct trialuser tu;

	if ((date = trialuser(s, uname))) {
		printf("User %s is already in trial, and has %i days left of it.\n",
		       uname, daysleft(time(NULL), date, s->trialdays));
		return -1;
	}

	if (!userexists(s->passwd, uname)) {
		printf("User %s doesn't exist in %s.\n", uname, s->passwd);
		return -1;
	}

#warning: check if user is exempt
	
#ifdef _BSD_
	if ((fd = open(s->trialfile, O_CREAT | O_WRONLY | O_APPEND | O_EXLOCK, 0666)) == -1)
#else
	if ((fd = open(s->trialfile, O_CREAT | O_WRONLY | O_APPEND, 0666)) == -1)
#endif
	{
		printf("Can't open trial database file %s: %s\n",
		        s->trialfile, strerror(errno));
		return -1;
	}

	tu.date = time(NULL);
	strncpy(tu.uname, uname, 24);

	write(fd, &tu, sizeof(struct trialuser));
	close(fd);

	return tu.date;
}

int removefromtrial(const struct settings *s, const char *uname)
{
	int fd, i, max, date = 0;
	struct trialuser tu, *tmptu = 0;

#ifdef _BSD_
	if ((fd = open(s->trialfile, O_RDONLY | O_EXLOCK)) == -1)
#else
	if ((fd = open(s->trialfile, O_RDONLY)) == -1)
#endif
	{
		printf("Can't open trial database file %s: %s\n",
		        s->trialfile, strerror(errno));
		return -1;
	}

	for (i = 0; (read(fd, &tu, sizeof(struct trialuser)));) {
		if (strncmp(tu.uname, uname, 24) != 0) {
			tmptu = realloc(tmptu, sizeof(struct trialuser)*(i+1));
			memcpy(&tmptu[i], &tu, sizeof(struct trialuser));
			i++;
		} else {
			date = (int)tu.date;
		}
	}
	
	close(fd);

#ifdef _BSD_
	if ((fd = open(s->trialfile, O_TRUNC | O_WRONLY | O_EXLOCK, 0666)) == -1)
#else
	if ((fd = open(s->trialfile, O_TRUNC | O_WRONLY, 0666)) == -1)
#endif
	{
		printf("Can't open trial database file %s: %s\n",
		        s->trialfile, strerror(errno));
		if (tmptu) free(tmptu);
		return -1;
	}
	
	max = i;
	for (i = 0; i < max; i++)
		write(fd, &tmptu[i], sizeof(struct trialuser));
	
	close(fd);
	if (tmptu) free(tmptu);

	return date;
}

int trialuser(const struct settings *s, const char *uname)
{
	int fd, ret = 0;
	struct trialuser tu;

#ifdef __BSD_
	if ((fd = open(s->trialfile, O_RDONLY | O_EXLOCK)) == -1)
#else
	if ((fd = open(s->trialfile, O_RDONLY)) == -1)
#endif
	{
		writelog(s->logfile, "trialuser: open(%s): %s\n", s->trialfile, strerror(errno));
		return ret;
	}
	
	while (read(fd, &tu, sizeof(struct trialuser))) {
		if (strncmp(uname, tu.uname, 24) == 0) {
			ret = tu.date;
			break;
		}
	}

	close(fd);
	return ret;
}

void printtrials(const struct settings *s)
{
	int fd;
	struct trialuser tu;
	
#ifdef __BSD_
	if ((fd = open(s->trialfile, O_RDONLY | O_EXLOCK)) == -1)
#else
	if ((fd = open(s->trialfile, O_RDONLY)) == -1)
#endif
	{
		writelog(s->logfile, "trialuser: open(%s): %s\n", s->trialfile, strerror(errno));
		return;
	}
	
	printf("\nUsers stored in the trialdata file:\n");
	printf("\n");
	while (read(fd, &tu, sizeof(struct trialuser)))
		printf("%-24s - %i days\n", tu.uname, daysleft(time(NULL), tu.date, s->trialdays));
	printf("\n");

	close(fd);
}

