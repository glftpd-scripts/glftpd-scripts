#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include "quota.h"
#include "helpfuncs.h"
#include "glfuncs.h"
#include "userfuncs.h"
#include "objects.h"

int main(int argc, char **argv)
{

	int ch, mode=0, i;
	char *endptr, temp[PATH_MAX] = { 0 };
	struct gluser *userlist = 0;
	struct settings s;
	
	// get arguments for only config and mode, because they need to
	// be taken care of first if they are present
	while ((ch = getopt(argc, argv, "m:r:c:d:pfth")) != -1) {
		switch (ch) {
			case 'r':
				strncpy(temp, optarg, PATH_MAX);
				break;
			case 'm':
				mode = strtol(optarg, &endptr, 10);
				if (strcmp(optarg, endptr) == 0) {
					fprintf(stderr, "error: The argument for \"-m\" has to be a valid integer.\n");
					return EXIT_FAILURE;
				} else if (mode < 0 || mode > 2) {
					print_usage();
					return EXIT_FAILURE;
				}
				break;
			case 'h':
				print_usage();
				full_help();
				return EXIT_SUCCESS;
			default:
				break;
		}
	}

	if (strlen(temp) == 0) {
		print_usage();
		return EXIT_FAILURE;
	}

	readconfig(temp, &s);

	// this program runs at an ordinary shell - but this is ugly
	snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.userdir);
	strncpy(s.userdir, temp, PATH_MAX);
	snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.passwd);
	strncpy(s.passwd, temp, PATH_MAX);
	snprintf(temp, PATH_MAX, "%s/%s", s.glroot, s.trialfile);
	strncpy(s.trialfile, temp, PATH_MAX);
	
	s.n_users = countlines(s.passwd);
	
#ifdef __BSD_
	optind = optreset = 1;
#else
	optind = opterr = optopt = 0;
#endif

	userlist = builduserlist(&s, userlist);

	// walk through the argument list and exit after a function
	// is finished because we don't want multiple things happening
	while ((ch = getopt(argc, argv, "r:c:d:pfth")) != -1) {
		switch (ch) {
			case 'c':
				while (optarg[strlen(optarg)-1] == ' ')
					optarg[strlen(optarg)-1] = '\0';
	
				singlecheck(userlist, &s, optarg);
				goto FINISH;
			case 'd':
				
				switch (*optarg) {
					case 'q':
						quotacleanup(userlist, &s, mode);
						break;
					case 't':
						trialcleanup(userlist, &s, mode);
						break;
					default:
						break;
				}

				goto FINISH;

			case 'p':
				quotacheck(userlist, &s, 0);
				goto FINISH;
			case 'f':
				quotacheck(userlist, &s, 1);
				goto FINISH;
			case 't':
				trialcheck(userlist, &s);
				goto FINISH;
			default:
				break;
		}
	}
				
	print_usage();

FINISH:
	if (userlist) {
		for (i = 0; i < s.n_users; i++) {
			if (userlist[i].section[0].s)
				free(userlist[i].section[0].s);
			if (userlist[i].section[1].s)
				free(userlist[i].section[1].s);
		}
		free(userlist);
	}

	if (s.gquota.gq)
		free(s.gquota.gq);

	if (s.qlimit)
		free(s.qlimit);
	
	return EXIT_SUCCESS;
	
}

void print_usage()
{
	fprintf(stderr, "Usage: quota -r <config> [ -f | -p | -t | -c <user> | -d <q/t> | -m <0/1/2> | -h ]\n");
}

void full_help()
{
	fprintf(stderr, "\n\t-r <config>\t- Specify the location of the config file.\n");
	fprintf(stderr, "\t-p\t\t- Show passed users.\n");
	fprintf(stderr, "\t-f\t\t- Show failed users.\n");
	fprintf(stderr, "\t-t\t\t- Show users on trial.\n");
	fprintf(stderr, "\t-c <user>\t- Show information about a single user.\n");
	fprintf(stderr, "\t-d <q/t>\t- Make a cleanup of users in either quota (q)\n\t\t\t  or trial (t)\n");
	fprintf(stderr, "\n\t-m <0/1/2>\t    Cleanup mode.\n");
	fprintf(stderr, "\t\t\t0 - Quota is only checked if the current day is the\n\t\t\t    last in the month (default). This doesn't apply\n");
	fprintf(stderr, "\t\t\t    to trial.\n"); 
	fprintf(stderr, "\t\t\t1 - A test that shows what would happen if the cleanup\n\t\t\t    was real.\n");
	fprintf(stderr, "\t\t\t2 - Force a cleanup no matter what the date is. This\n\t\t\t    is the default for trial cleanup.\n");
	fprintf(stderr, "\n\t-h\t\t- Show this text.\n\n");
}
