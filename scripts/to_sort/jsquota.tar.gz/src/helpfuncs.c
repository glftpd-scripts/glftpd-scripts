#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "helpfuncs.h"
#include "static.h"
#include "objects.h"

void writelog(const char *file, const char *fmt, ...)
{
	time_t tp;
	va_list ap;
	FILE *fp;

	if (fmt == NULL || file == NULL || strlen(file) == 0)
		return;
	
	if (!(fp = fopen(file, "a"))) {
		perror(file);
		exit(EXIT_FAILURE);
	}

	va_start(ap, fmt);
	
	tp = time(NULL);
	
	fprintf(fp, "[%.24s]: ", ctime(&tp));
	vfprintf(fp, fmt, ap);
	
	va_end(ap);
	fclose(fp);
}

char *getcfgvalue(FILE *config, const char *option, char *dest)
{
	int bytes=64;
	char *buf, *p, *optp;

	buf = malloc(bytes);
	
	fseek(config, 0L, SEEK_SET);
	while ((fgets(buf, bytes, config))) {

		// if there isnt a \n in the buffer
		// i increase the buffer and read again
		// from the beginning
		if (buf[strlen(buf)-1] != '\n' && bytes <= MAXSTRLEN) {
			bytes *= 2;
			buf = realloc(buf, bytes);
			fseek(config, 0L, SEEK_SET);
			continue;
		}

		optp = buf;
		while (*optp == ' ' || *optp == '\t')
			optp++;

		if ((p = strstr(optp, "#")))
			*p = '\0';

		if ((p = strstr(optp, "="))) {
			*p = '\0';
			if (strncasecmp(optp, option, strlen(option)) == 0) {
				*p = ' ';
				// remove whitespaces in the beginning
				while (*p == ' ') p++;

				// replace newline with end of line
				buf[strlen(buf)-1] = '\0';
				
				dest = realloc(dest, strlen(p)+1);

				strcpy(dest, p);
				free(buf);
				return dest;
			}
		}
	}

	free(buf);
	return NULL;
}

long getcfgvalue_l(FILE *config, const char *option)
{
	long val=0;
	char *p=0, *endptr;

	if ((p = getcfgvalue(config, option, p))) {
		val = strtol(p, &endptr, 10);
		if (strcmp(p, endptr) == 0) {
			if (p) free(p);
			return 0;
		} else {
			if (p) free(p);
			return val;
		}
	} else
		return 0;
}

size_t countlines(const char *filename)
{
	size_t lines = 0;
	char c;
	FILE *in;

	in = fopen(filename, "r");

	if (in == NULL) {
		perror(filename);
		return 0;
	}
	
	while ((c = getc(in)) != EOF)
		if (c == '\n')
			lines++;
	
	fclose(in);
	
	return lines;
}

/* find the number of days now, since then */
int daysleft(time_t now, time_t then, int limit)
{
	time_t n_days = 0, t_days = 0, clock;
	struct tm *tm;

	if (then > 0) {
		n_days = now/60/60/24;
		t_days = then/60/60/24;
	} else {
		clock = time(NULL);
		tm = localtime((time_t *)&clock);
		n_days = tm->tm_mday;
		if (tm->tm_year%4 == 0)
			limit = MONTHS_LEAP[tm->tm_mon];
		else
			limit = MONTHS[tm->tm_mon];
	}

	return limit-((int)(n_days-t_days));
}

/* find the last occurance of any of delim in name */
char *find_last_of(char *name, const char *delim)
{
	char		*n_ptr, *result;
	const char	*d_ptr;

	for (result = n_ptr = name; *n_ptr; n_ptr++)
		for (d_ptr = delim; *d_ptr; d_ptr++)
			if (*n_ptr == *d_ptr)
				result = n_ptr;
	
	return result;
}

/* find the first occurance of any of delim in name */
char *find_first_of(char *name, const char *delim)
{
	char		*n_ptr;
	const char	*d_ptr;

	for (n_ptr = name; *n_ptr; n_ptr++)
		for (d_ptr = delim; *d_ptr; d_ptr++)
			if (*n_ptr == *d_ptr)
				return n_ptr;
	
	return n_ptr;
}

/* remove trailing whitespaces and newline stuff */
/*void strip_whitespaces(char *s)
{
	size_t len = strlen(s)-1;
	
	while (s[len] == ' '  ||
	       s[len] == '\t' ||
	       s[len] == '\n' ||
	       s[len] == '\r') {
	       	s[len] = '\0';
			len--;
	}
}*/

#warning: make this run an arbitrary amount of commands
void runcomplete(const struct settings *s, char *fmt, ...)
{
	int args;
	pid_t pid;
	char *cmdv[7], tmp[16];
	va_list ap;

	for (args = 0; args < 7; args++)
		cmdv[args] = 0;
	
	args = 0;

	va_start(ap, fmt);
	while (*fmt) {
		switch (*fmt++) {
			case 's':
				cmdv[args++] = strdup(va_arg(ap, char *));
				break;
			case 'i':
				bzero(tmp, 16);
				snprintf(tmp, 16, "%i", va_arg(ap, int));
				cmdv[args++] = strdup(tmp);
				break;
			default:
				break;
		}
	}
	va_end(ap);
	
	switch ((pid = fork())) {
		case -1:
			writelog(s->logfile, "runcomplete: fork(): %s\n", strerror(errno));
			break;
		case 0:
			execv(cmdv[0], cmdv);
			writelog(s->logfile, "runcomplete: execv(%s): %s\n", cmdv[0], strerror(errno));
			exit(1);
		default:
			waitpid(pid, NULL, WUNTRACED);
			break;
	}

	for (args = 0; args < 7; args++)
		if (cmdv[args])
			free(cmdv[args]);
}

